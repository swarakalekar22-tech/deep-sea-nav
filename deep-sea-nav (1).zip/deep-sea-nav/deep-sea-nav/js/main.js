// Utility selectors
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

document.addEventListener("DOMContentLoaded", () => {
  initNavbar();
  initScrollAnimations();
  initSonarCanvas();
  initAISystem();
  initFooterYear();
});

function initNavbar() {
  const navbar = $("#navbar");
  const navToggle = $("#navToggle");
  const navMobile = $("#navMobile");
  const navLinks = $$(".nav-link");
  const mobileLinks = $$(".nav-mobile-link");

  const onScroll = () => {
    if (window.scrollY > 40) navbar.classList.add("scrolled");
    else navbar.classList.remove("scrolled");
  };
  window.addEventListener("scroll", onScroll);
  onScroll();

  const toggleMobile = () => {
    const isOpen = navToggle.classList.toggle("open");
    navMobile.classList.toggle("open", isOpen);
  };

  navToggle.addEventListener("click", toggleMobile);

  const allLinks = [...navLinks, ...mobileLinks];
  allLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
      const href = link.getAttribute("href");
      if (!href || !href.startsWith("#")) return;
      e.preventDefault();
      const target = document.querySelector(href);
      if (target) {
        const navHeight = navbar.getBoundingClientRect().height;
        const top = target.getBoundingClientRect().top + window.scrollY - navHeight + 4;
        window.scrollTo({ top, behavior: "smooth" });
      }
      if (navMobile.classList.contains("open")) {
        navMobile.classList.remove("open");
        navToggle.classList.remove("open");
      }
    });
  });
}

function initScrollAnimations() {
  const elems = $$("[data-animate]");
  const techBars = $$("[data-techbar] .tech-bar-fill");

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  elems.forEach((el) => observer.observe(el));

  const barsObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const fill = entry.target.querySelector(".tech-bar-fill");
          if (fill) fill.classList.add("grow");
          barsObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.3 }
  );
  $$("[data-techbar]").forEach((el) => barsObserver.observe(el));
}

// Hero sonar canvas animation
function initSonarCanvas() {
  const canvas = document.getElementById("heroSonarCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");

  let width, height, centerX, centerY, radius;
  let particles = [];
  const particleCount = 80;
  const rings = [];
  let lastRingTime = 0;
  const ringInterval = 2000;
  let angle = 0;

  function resize() {
    const rect = canvas.getBoundingClientRect();
    width = canvas.width = rect.width * window.devicePixelRatio;
    height = canvas.height = rect.height * window.devicePixelRatio;
    ctx.setTransform(window.devicePixelRatio, 0, 0, window.devicePixelRatio, 0, 0);
    centerX = rect.width / 2;
    centerY = rect.height / 2 - 40;
    radius = Math.min(rect.width, rect.height) * 0.45;
  }

  function createParticles() {
    particles = [];
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        r: Math.random() * 2 + 0.5,
        vx: (Math.random() - 0.5) * 0.15,
        vy: (Math.random() - 0.5) * 0.15,
        alpha: Math.random() * 0.5 + 0.2,
      });
    }
  }

  function drawBackground() {
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "#020b18";
    ctx.fillRect(0, 0, width, height);

    ctx.save();
    ctx.translate(centerX, centerY);

    ctx.strokeStyle = "rgba(0, 212, 255, 0.2)";
    ctx.lineWidth = 1;
    for (let r = radius * 0.25; r <= radius; r += radius * 0.25) {
      ctx.beginPath();
      ctx.arc(0, 0, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.beginPath();
    ctx.moveTo(-radius, 0);
    ctx.lineTo(radius, 0);
    ctx.moveTo(0, -radius);
    ctx.lineTo(0, radius);
    ctx.stroke();

    ctx.restore();
  }

  function drawParticles() {
    ctx.fillStyle = "#00d4ff";
    particles.forEach((p) => {
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0) p.x = width;
      if (p.x > width) p.x = 0;
      if (p.y < 0) p.y = height;
      if (p.y > height) p.y = 0;
      ctx.globalAlpha = p.alpha;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
  }

  function spawnRing(now) {
    if (now - lastRingTime > ringInterval) {
      rings.push({ t: now, startRadius: radius * 0.15 });
      lastRingTime = now;
    }
  }

  function drawRings(now) {
    ctx.save();
    ctx.translate(centerX, centerY);
    for (let i = rings.length - 1; i >= 0; i--) {
      const ring = rings[i];
      const age = (now - ring.t) / 1000;
      const r = ring.startRadius + age * radius * 0.6;
      const alpha = Math.max(0, 0.6 - age * 0.6);
      if (alpha <= 0 || r > radius * 1.2) {
        rings.splice(i, 1);
        continue;
      }
      ctx.strokeStyle = `rgba(0, 212, 255, ${alpha})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, r, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawScanLine() {
    ctx.save();
    ctx.translate(centerX, centerY);
    ctx.rotate(angle);
    const grad = ctx.createRadialGradient(0, 0, 0, 0, 0, radius);
    grad.addColorStop(0, "rgba(0, 212, 255, 0.45)");
    grad.addColorStop(1, "rgba(0, 212, 255, 0)");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, radius, -0.18, 0.18);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function loop(now) {
    drawBackground();
    drawParticles();
    spawnRing(now);
    drawRings(now);
    drawScanLine();

    angle += 0.01;
    requestAnimationFrame(loop);
  }

  resize();
  createParticles();
  window.addEventListener("resize", () => {
    resize();
    createParticles();
  });
  requestAnimationFrame(loop);
}

// AI computation helpers
function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const toRad = (deg) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.asin(Math.sqrt(a));
  return R * c;
}

function bearing(lat1, lon1, lat2, lon2) {
  const toRad = (deg) => (deg * Math.PI) / 180;
  const toDeg = (rad) => (rad * 180) / Math.PI;
  const phi1 = toRad(lat1);
  const phi2 = toRad(lat2);
  const dLon = toRad(lon2 - lon1);
  const y = Math.sin(dLon) * Math.cos(phi2);
  const x =
    Math.cos(phi1) * Math.sin(phi2) -
    Math.sin(phi1) * Math.cos(phi2) * Math.cos(dLon);
  let brng = toDeg(Math.atan2(y, x));
  brng = (brng + 360) % 360;
  return brng;
}

function classifyObstacle(distanceMeters) {
  if (distanceMeters > 100) {
    return {
      level: "SAFE",
      badge: "badge-safe",
      action: "Surface track is clear ahead. Maintain current heading and speed.",
    };
  }
  if (distanceMeters >= 50) {
    return {
      level: "CAUTION",
      badge: "badge-caution",
      action:
        "Surface contact detected within caution range. Reduce speed and prepare to adjust course.",
    };
  }
  return {
    level: "DANGER",
    badge: "badge-danger",
    action:
      "Immediate surface hazard ahead. Execute evasive maneuver and alter course away from obstacle.",
  };
}

// Simple A* on 20x20 grid
function astar(start, goal, blockedSet) {
  const key = (x, y) => `${x},${y}`;
  const gridSize = 20;

  const open = [];
  const g = new Map();
  const f = new Map();
  const cameFrom = new Map();

  const h = (a, b) => Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]);

  const pushOpen = (node, fScore) => {
    open.push({ node, fScore });
    open.sort((a, b) => a.fScore - b.fScore);
  };

  g.set(key(start[0], start[1]), 0);
  f.set(key(start[0], start[1]), h(start, goal));
  pushOpen(start, h(start, goal));

  const neighbors = (x, y) => {
    const deltas = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ];
    const results = [];
    for (const [dx, dy] of deltas) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= gridSize || ny >= gridSize) continue;
      if (blockedSet.has(key(nx, ny))) continue;
      results.push([nx, ny]);
    }
    return results;
  };

  while (open.length) {
    const current = open.shift().node;
    const [cx, cy] = current;
    if (cx === goal[0] && cy === goal[1]) {
      const path = [];
      let curKey = key(cx, cy);
      let cur = current;
      while (cameFrom.has(curKey)) {
        path.push(cur);
        cur = cameFrom.get(curKey);
        curKey = key(cur[0], cur[1]);
      }
      path.push(start);
      return path.reverse();
    }

    for (const [nx, ny] of neighbors(cx, cy)) {
      const nKey = key(nx, ny);
      const tentativeG = g.get(key(cx, cy)) + 1;
      if (tentativeG < (g.get(nKey) ?? Infinity)) {
        cameFrom.set(nKey, [cx, cy]);
        g.set(nKey, tentativeG);
        const fScore = tentativeG + h([nx, ny], goal);
        f.set(nKey, fScore);
        if (!open.some((o) => o.node[0] === nx && o.node[1] === ny)) {
          pushOpen([nx, ny], fScore);
        }
      }
    }
  }

  return [start, goal];
}

function drawRoute(path, blocked, canvas) {
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const size = 20;
  const w = canvas.width;
  const h = canvas.height;
  const cell = Math.min(w, h) / size;

  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#020b18";
  ctx.fillRect(0, 0, w, h);

  ctx.strokeStyle = "rgba(255,255,255,0.05)";
  ctx.lineWidth = 1;
  for (let i = 0; i <= size; i++) {
    ctx.beginPath();
    ctx.moveTo(i * cell, 0);
    ctx.lineTo(i * cell, h);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, i * cell);
    ctx.lineTo(w, i * cell);
    ctx.stroke();
  }

  ctx.fillStyle = "rgba(255, 56, 96, 0.8)";
  blocked.forEach((k) => {
    const [x, y] = k.split(",").map(Number);
    ctx.fillRect(x * cell, y * cell, cell, cell);
  });

  if (!path || path.length === 0) return;

  ctx.strokeStyle = "#00ff88";
  ctx.lineWidth = 2;
  ctx.beginPath();
  path.forEach(([x, y], idx) => {
    const cx = x * cell + cell / 2;
    const cy = y * cell + cell / 2;
    if (idx === 0) ctx.moveTo(cx, cy);
    else ctx.lineTo(cx, cy);
  });
  ctx.stroke();

  const [sx, sy] = path[0];
  const [ex, ey] = path[path.length - 1];
  ctx.fillStyle = "#00d4ff";
  ctx.beginPath();
  ctx.arc(sx * cell + cell / 2, sy * cell + cell / 2, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#ffd700";
  ctx.beginPath();
  ctx.arc(ex * cell + cell / 2, ey * cell + cell / 2, 4, 0, Math.PI * 2);
  ctx.fill();
}

function setPreset(type) {
  const startLat = $("#startLat");
  const startLon = $("#startLon");
  const destLat = $("#destLat");
  const destLon = $("#destLon");

  if (!startLat || !startLon || !destLat || !destLon) return;

  if (type === "mumbai-goa") {
    startLat.value = "19.0760";
    startLon.value = "72.8777";
    destLat.value = "15.2993";
    destLon.value = "74.1240";
  } else if (type === "gulf") {
    startLat.value = "25.2048"; // Dubai
    startLon.value = "55.2708";
    destLat.value = "26.4207"; // Bahrain
    destLon.value = "50.0888";
  } else if (type === "random") {
    const baseLat = 18;
    const baseLon = 72;
    startLat.value = (baseLat + (Math.random() - 0.5) * 4).toFixed(4);
    startLon.value = (baseLon + (Math.random() - 0.5) * 4).toFixed(4);
    destLat.value = (baseLat + (Math.random() - 0.5) * 4).toFixed(4);
    destLon.value = (baseLon + (Math.random() - 0.5) * 4).toFixed(4);
  }
}

function runAI() {
  const btn = $("#aiRunBtn");
  const startLat = parseFloat($("#startLat").value);
  const startLon = parseFloat($("#startLon").value);
  const destLat = parseFloat($("#destLat").value);
  const destLon = parseFloat($("#destLon").value);
  const obstacle = parseFloat($("#obstacleRange").value);

  const idle = $("#aiOutputIdle");
  const live = $("#aiOutputLive");

  idle.style.display = "none";
  live.classList.remove("visible");

  btn.disabled = true;
  const originalText = btn.textContent;
  btn.textContent = "⟳ COMPUTING...";

  setTimeout(() => {
    const distKm = haversine(startLat, startLon, destLat, destLon);
    const head = bearing(startLat, startLon, destLat, destLon);
    const speedKnots = 12;
    const etaMin = (distKm / (speedKnots * 1.852)) * 60;

    const obs = classifyObstacle(obstacle);

    $("#outHeading").textContent = `${head.toFixed(1)}°`;
    $("#outDistance").textContent = `${distKm.toFixed(1)} km`;
    $("#outEta").textContent = `${etaMin.toFixed(0)} min`;

    const badge = $("#outStatusBadge");
    badge.textContent = obs.level;
    badge.className = `badge ${obs.badge}`;
    $("#outAction").textContent = obs.action;

    const blocked = new Set();
    const gridSize = 20;
    const toGrid = (lat, lon) => {
      const normLat = (lat + 90) / 180;
      const normLon = (lon + 180) / 360;
      return [
        Math.max(0, Math.min(gridSize - 1, Math.floor(normLon * gridSize))),
        Math.max(0, Math.min(gridSize - 1, Math.floor(normLat * gridSize))),
      ];
    };

    const [sx, sy] = toGrid(startLat, startLon);
    const [gx, gy] = toGrid(destLat, destLon);

    for (let i = 0; i < 30; i++) {
      const x = Math.floor(Math.random() * gridSize);
      const y = Math.floor(Math.random() * gridSize);
      const key = `${x},${y}`;
      if (key === `${sx},${sy}` || key === `${gx},${gy}`) continue;
      blocked.add(key);
    }

    const path = astar([sx, sy], [gx, gy], blocked);
    const canvas = document.getElementById("routeCanvas");
    drawRoute(path, blocked, canvas);

    live.classList.add("visible");
    btn.disabled = false;
    btn.textContent = originalText;
  }, 800);
}

function initAISystem() {
  const form = $("#aiForm");
  const range = $("#obstacleRange");
  const rangeLabel = $("#obstacleRangeValue");

  if (range && rangeLabel) {
    rangeLabel.textContent = `${range.value} m`;
    range.addEventListener("input", () => {
      rangeLabel.textContent = `${range.value} m`;
    });
  }

  $$(".chip-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const type = btn.getAttribute("data-preset");
      setPreset(type);
    });
  });

  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      runAI();
    });
  }
}

function initFooterYear() {
  const span = document.getElementById("footerYear");
  if (span) span.textContent = new Date().getFullYear();
}

