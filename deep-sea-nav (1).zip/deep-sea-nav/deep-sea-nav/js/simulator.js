(function () {
  const canvas = document.getElementById("simCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");

  const GRID_CELL = 20;
  const COLS = Math.floor(canvas.width / GRID_CELL);
  const ROWS = Math.floor(canvas.height / GRID_CELL);

  const hud = {
    status: document.getElementById("hudStatus"),
    position: document.getElementById("hudPosition"),
    heading: document.getElementById("hudHeading"),
    speed: document.getElementById("hudSpeed"),
    front: document.getElementById("hudSensorFront"),
    port: document.getElementById("hudSensorPort"),
    starboard: document.getElementById("hudSensorStarboard"),
    threatBar: document.getElementById("hudThreatBar"),
    threatLabel: document.getElementById("hudThreatLabel"),
    instruction: document.getElementById("hudInstruction"),
  };

  let vessel = {
    x: GRID_CELL * 3,
    y: canvas.height - GRID_CELL * 3,
    angle: -45,
    speed: 0,
  };

  let route = [];
  let routeIndex = 0;
  let destination = null;
  let obstacles = [];
  let status = "IDLE";
  let lastTime = performance.now();

  function genObstacles() {
    obstacles = [];
    const margin = 3;
    while (obstacles.length < 9) {
      const cx = Math.floor(Math.random() * COLS);
      const cy = Math.floor(Math.random() * ROWS);
      if (cx < margin && cy > ROWS - margin - 1) continue;
      obstacles.push({ x: cx * GRID_CELL + GRID_CELL / 2, y: cy * GRID_CELL + GRID_CELL / 2, r: 10, phase: Math.random() * Math.PI * 2 });
    }
  }

  function resetVessel() {
    vessel = {
      x: GRID_CELL * 3,
      y: canvas.height - GRID_CELL * 3,
      angle: -45,
      speed: 0,
    };
    route = [];
    routeIndex = 0;
    destination = null;
    status = "IDLE";
  }

  function autoNavigate() {
    setDestination(canvas.width - GRID_CELL * 3, GRID_CELL * 3);
  }

  function toGrid(x, y) {
    return {
      gx: Math.max(0, Math.min(COLS - 1, Math.floor(x / GRID_CELL))),
      gy: Math.max(0, Math.min(ROWS - 1, Math.floor(y / GRID_CELL))),
    };
  }

  function pixelAstar(sx, sy, ex, ey) {
    const { gx: startX, gy: startY } = toGrid(sx, sy);
    const { gx: endX, gy: endY } = toGrid(ex, ey);
    const blocked = new Set();

    for (const o of obstacles) {
      const { gx, gy } = toGrid(o.x, o.y);
      for (let dx = -1; dx <= 1; dx++) {
        for (let dy = -1; dy <= 1; dy++) {
          const bx = gx + dx;
          const by = gy + dy;
          if (bx >= 0 && bx < COLS && by >= 0 && by < ROWS) {
            blocked.add(`${bx},${by}`);
          }
        }
      }
    }

    const key = (x, y) => `${x},${y}`;
    const open = [];
    const g = new Map();
    const f = new Map();
    const came = new Map();
    const h = (a, b) => Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]);
    const pushOpen = (node, fs) => {
      open.push({ node, fs });
      open.sort((a, b) => a.fs - b.fs);
    };

    const start = [startX, startY];
    const goal = [endX, endY];
    g.set(key(startX, startY), 0);
    f.set(key(startX, startY), h(start, goal));
    pushOpen(start, h(start, goal));

    const neighbors = (x, y) => {
      const res = [];
      const deltas = [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ];
      for (const [dx, dy] of deltas) {
        const nx = x + dx;
        const ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= COLS || ny >= ROWS) continue;
        if (blocked.has(key(nx, ny))) continue;
        res.push([nx, ny]);
      }
      return res;
    };

    while (open.length) {
      const current = open.shift().node;
      const [cx, cy] = current;
      if (cx === goal[0] && cy === goal[1]) {
        const path = [];
        let cur = current;
        let ck = key(cx, cy);
        while (came.has(ck)) {
          path.push(cur);
          cur = came.get(ck);
          ck = key(cur[0], cur[1]);
        }
        path.push(start);
        return path.reverse().map(([x, y]) => ({
          x: x * GRID_CELL + GRID_CELL / 2,
          y: y * GRID_CELL + GRID_CELL / 2,
        }));
      }
      for (const [nx, ny] of neighbors(cx, cy)) {
        const nk = key(nx, ny);
        const tentativeG = g.get(key(cx, cy)) + 1;
        if (tentativeG < (g.get(nk) ?? Infinity)) {
          came.set(nk, [cx, cy]);
          g.set(nk, tentativeG);
          const fs = tentativeG + h([nx, ny], goal);
          f.set(nk, fs);
          if (!open.some((o) => o.node[0] === nx && o.node[1] === ny)) {
            pushOpen([nx, ny], fs);
          }
        }
      }
    }

    return [
      { x: startX * GRID_CELL + GRID_CELL / 2, y: startY * GRID_CELL + GRID_CELL / 2 },
      { x: endX * GRID_CELL + GRID_CELL / 2, y: endY * GRID_CELL + GRID_CELL / 2 },
    ];
  }

  function setDestination(x, y) {
    for (const o of obstacles) {
      const dx = x - o.x;
      const dy = y - o.y;
      if (Math.sqrt(dx * dx + dy * dy) < o.r + 10) {
        return;
      }
    }
    destination = { x, y };
    route = pixelAstar(vessel.x, vessel.y, x, y);
    routeIndex = 0;
    status = "NAVIGATING";
    vessel.speed = 2;
  }

  function drawOcean() {
    ctx.fillStyle = "#020d1a";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = "rgba(0, 212, 255, 0.08)";
    ctx.lineWidth = 1;
    for (let x = 0; x <= canvas.width; x += GRID_CELL) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y <= canvas.height; y += GRID_CELL) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    const time = performance.now() / 1000;
    ctx.strokeStyle = "rgba(0, 212, 255, 0.15)";
    for (let y = 0; y < canvas.height; y += 40) {
      ctx.beginPath();
      for (let x = 0; x <= canvas.width; x += 10) {
        const offset = Math.sin((x / 100) + time) * 4;
        if (x === 0) ctx.moveTo(x, y + offset);
        else ctx.lineTo(x, y + offset);
      }
      ctx.stroke();
    }
  }

  function drawObstacles() {
    const time = performance.now() / 700;
    for (const o of obstacles) {
      ctx.fillStyle = "#ff3860";
      ctx.beginPath();
      ctx.arc(o.x, o.y, o.r, 0, Math.PI * 2);
      ctx.fill();

      const pulse = (Math.sin(time + o.phase) + 1) / 2;
      const pr = o.r + 6 + pulse * 6;
      ctx.strokeStyle = `rgba(255, 56, 96, ${0.6 - pulse * 0.4})`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(o.x, o.y, pr, 0, Math.PI * 2);
      ctx.stroke();
    }
  }

  function drawRoute() {
    if (!route.length) return;
    ctx.lineWidth = 2;

    ctx.strokeStyle = "#00ff88";
    ctx.setLineDash([]);
    ctx.beginPath();
    for (let i = 0; i <= routeIndex && i < route.length; i++) {
      const p = route[i];
      if (i === 0) ctx.moveTo(p.x, p.y);
      else ctx.lineTo(p.x, p.y);
    }
    ctx.stroke();

    if (routeIndex < route.length - 1) {
      ctx.strokeStyle = "#00d4ff";
      ctx.setLineDash([6, 6]);
      ctx.beginPath();
      ctx.moveTo(vessel.x, vessel.y);
      for (let i = Math.max(routeIndex, 0); i < route.length; i++) {
        const p = route[i];
        ctx.lineTo(p.x, p.y);
      }
      ctx.stroke();
      ctx.setLineDash([]);
    }
  }

  function drawDestination() {
    if (!destination) return;
    const { x, y } = destination;
    const time = performance.now() / 800;

    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(time);
    ctx.fillStyle = "#ffd700";
    ctx.beginPath();
    const size = 10;
    for (let i = 0; i < 5; i++) {
      const angle = (i * 2 * Math.PI) / 5 - Math.PI / 2;
      const inner = size * 0.4;
      const outer = size;
      ctx.lineTo(Math.cos(angle) * outer, Math.sin(angle) * outer);
      ctx.lineTo(
        Math.cos(angle + Math.PI / 5) * inner,
        Math.sin(angle + Math.PI / 5) * inner
      );
    }
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    const pulse = (Math.sin(time * 2) + 1) / 2;
    const radius = 18 + pulse * 6;
    ctx.strokeStyle = `rgba(255, 215, 0, ${0.5 - pulse * 0.3})`;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.stroke();
  }

  function drawSensorLines() {
    const rays = getSensorRays();
    ctx.setLineDash([4, 4]);
    ctx.lineWidth = 1;
    for (const r of rays) {
      ctx.strokeStyle = "rgba(0, 212, 255, 0.4)";
      ctx.beginPath();
      ctx.moveTo(vessel.x, vessel.y);
      ctx.lineTo(r.x, r.y);
      ctx.stroke();
    }
    ctx.setLineDash([]);
  }

  function getSensorRays() {
    const range = 180;
    const angles = [0, -45, 45].map((a) => ((vessel.angle + a) * Math.PI) / 180);
    return angles.map((theta) => ({
      x: vessel.x + Math.cos(theta) * range,
      y: vessel.y + Math.sin(theta) * range,
    }));
  }

  function drawVessel() {
    const { x, y, angle } = vessel;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate((angle * Math.PI) / 180);

    ctx.shadowColor = "#00d4ff";
    ctx.shadowBlur = 16;

    ctx.fillStyle = "#00d4ff";
    ctx.beginPath();
    const size = 14;
    ctx.moveTo(0, -size);
    ctx.lineTo(size * 0.7, size);
    ctx.lineTo(0, size * 0.4);
    ctx.lineTo(-size * 0.7, size);
    ctx.closePath();
    ctx.fill();

    ctx.shadowBlur = 0;
    ctx.fillStyle = "#ffd700";
    ctx.beginPath();
    ctx.arc(0, 0, 3, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  function castSensors() {
    const toMeters = (px) => px * 2;
    const results = { front: Infinity, port: Infinity, starboard: Infinity };
    const dirs = {
      front: vessel.angle,
      port: vessel.angle - 45,
      starboard: vessel.angle + 45,
    };

    Object.entries(dirs).forEach(([key, ang]) => {
      const rad = (ang * Math.PI) / 180;
      const maxDist = 250;
      let best = Infinity;
      for (let o of obstacles) {
        const dx = o.x - vessel.x;
        const dy = o.y - vessel.y;
        const proj = dx * Math.cos(rad) + dy * Math.sin(rad);
        if (proj <= 0 || proj > maxDist) continue;
        const perp = Math.abs(-dx * Math.sin(rad) + dy * Math.cos(rad));
        if (perp < o.r + 8) {
          best = Math.min(best, proj);
        }
      }
      results[key] = best;
    });

    const f = results.front === Infinity ? "Clear" : `${Math.round(toMeters(results.front))} m`;
    const p = results.port === Infinity ? "Clear" : `${Math.round(toMeters(results.port))} m`;
    const s =
      results.starboard === Infinity ? "Clear" : `${Math.round(toMeters(results.starboard))} m`;

    hud.front.textContent = f;
    hud.port.textContent = p;
    hud.starboard.textContent = s;

    const nearest = Math.min(results.front, results.port, results.starboard);
    let threat = "SAFE";
    let bar = 0.2;
    let color = "var(--accent-green)";
    if (nearest < Infinity) {
      const m = toMeters(nearest);
      if (m < 50) {
        threat = "DANGER";
        bar = 1;
        color = "var(--accent-red)";
      } else if (m <= 100) {
        threat = "CAUTION";
        bar = 0.6;
        color = "var(--accent-gold)";
      } else {
        threat = "SAFE";
        bar = 0.3;
      }
    }

    hud.threatLabel.textContent = threat;
    hud.threatBar.style.width = `${bar * 100}%`;
    hud.threatBar.style.background = color;
  }

  function updateHUD(dt) {
    hud.status.textContent = status;

    const baseLat = 18;
    const baseLon = 72;
    const lat = baseLat + (canvas.height - vessel.y) / 1000;
    const lon = baseLon + vessel.x / 1000;
    hud.position.textContent = `${lat.toFixed(4)}, ${lon.toFixed(4)}`;

    const heading = ((vessel.angle % 360) + 360) % 360;
    hud.heading.textContent = `${heading.toFixed(0).padStart(3, "0")}°`;

    hud.speed.textContent = `${(vessel.speed * 1.1).toFixed(1)} kn`;

    castSensors();

    if (status === "IDLE") {
      hud.instruction.textContent =
        "Click anywhere on the grid to set a destination. DeepNav AI will compute a surface route.";
    } else if (status === "NAVIGATING") {
      hud.instruction.textContent =
        "Vessel is following an AI-computed route. Monitor sensors and threat level.";
    } else if (status === "ARRIVED") {
      hud.instruction.textContent =
        "Destination reached. Set a new point or regenerate obstacles to explore another route.";
    } else if (status === "DANGER") {
      hud.instruction.textContent =
        "Obstacle dangerously close. Consider resetting route or adjusting destination.";
    }
  }

  function moveVessel(dt) {
    if (!route.length || status !== "NAVIGATING") {
      vessel.speed = Math.max(0, vessel.speed - 0.02 * dt);
      return;
    }

    const target = route[Math.min(routeIndex + 1, route.length - 1)];
    const dx = target.x - vessel.x;
    const dy = target.y - vessel.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < 5) {
      routeIndex++;
      if (routeIndex >= route.length - 1) {
        status = "ARRIVED";
        vessel.speed = 0;
      }
      return;
    }

    const targetAngle = (Math.atan2(dy, dx) * 180) / Math.PI;
    let diff = targetAngle - vessel.angle;
    diff = ((diff + 540) % 360) - 180;
    vessel.angle += diff * 0.05;

    const speed = 2;
    vessel.speed = speed;
    vessel.x += Math.cos((vessel.angle * Math.PI) / 180) * speed;
    vessel.y += Math.sin((vessel.angle * Math.PI) / 180) * speed;

    const distToDest =
      destination &&
      Math.hypot(vessel.x - destination.x, vessel.y - destination.y);
    if (distToDest && distToDest < 15) {
      status = "ARRIVED";
      vessel.speed = 0;
    }
  }

  function loop(now) {
    const dt = (now - lastTime) / 16.67;
    lastTime = now;

    drawOcean();
    drawRoute();
    drawDestination();
    drawObstacles();
    drawSensorLines();
    drawVessel();
    updateHUD(dt);

    requestAnimationFrame(loop);
  }

  canvas.addEventListener("click", (e) => {
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setDestination(x, y);
  });

  document.getElementById("btnNewObstacles")?.addEventListener("click", () => {
    genObstacles();
    route = [];
    routeIndex = 0;
    destination = null;
    status = "IDLE";
  });

  document.getElementById("btnReset")?.addEventListener("click", () => {
    resetVessel();
  });

  document.getElementById("btnAuto")?.addEventListener("click", () => {
    autoNavigate();
  });

  genObstacles();
  resetVessel();
  requestAnimationFrame(loop);

  window.VesselSimulator = {
    genObstacles,
    resetVessel,
    autoNavigate,
  };
})();

