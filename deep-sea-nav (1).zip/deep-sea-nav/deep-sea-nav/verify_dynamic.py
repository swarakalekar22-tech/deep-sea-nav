from ai.navigation import compute_navigation
import json

def verify_dynamic_values():
    print("--- Verification: Dynamic Navigation Values ---")
    
    # Case 1: Safe Distance
    print("\nCase 1: Safe (Distance=120m, UW=150m)")
    res1 = compute_navigation(19.0, 72.0, 15.0, 74.0, 120, 150)
    print(f"SOG: {res1['sog_knots']}, STW: {res1['stw_knots']}, Depth: {res1['depth_meters']}, UW Depth: {res1['obstacle']['underwater_depth']}")
    
    # Case 2: Caution Distance
    print("\nCase 2: Caution (Distance=70m, UW=50m)")
    res2 = compute_navigation(19.0, 72.0, 15.0, 74.0, 70, 50)
    print(f"SOG: {res2['sog_knots']}, STW: {res2['stw_knots']}, Depth: {res2['depth_meters']}, UW Depth: {res2['obstacle']['underwater_depth']}")
    
    # Case 3: Danger Distance
    print("\nCase 3: Danger (Distance=20m, UW=10m)")
    res3 = compute_navigation(19.0, 72.0, 15.0, 74.0, 20, 10)
    print(f"SOG: {res3['sog_knots']}, STW: {res3['stw_knots']}, Depth: {res3['depth_meters']}, UW Depth: {res3['obstacle']['underwater_depth']}")

    # Assertions to ensure values are DIFFERENT
    assert res1['sog_knots'] != res2['sog_knots'], "SOG should change with distance!"
    assert res1['depth_meters'] != res2['depth_meters'], "Depth should change with distance!"
    assert res1['obstacle']['underwater_depth'] != res2['obstacle']['underwater_depth'], "UW Depth should change with UW distance!"
    
    print("\n[SUCCESS] All values are dynamic and respond to slider inputs.")

if __name__ == "__main__":
    verify_dynamic_values()
