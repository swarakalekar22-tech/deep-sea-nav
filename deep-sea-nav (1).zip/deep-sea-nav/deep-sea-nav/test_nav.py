from ai.navigation import compute_navigation
import json

def test_nav():
    try:
        print("Testing compute_navigation...")
        result = compute_navigation(19.0760, 72.8777, 15.2993, 74.1240, 120, 150)
        print("Success! Result keys:", result.keys())
        # print(json.dumps(result, indent=2))
    except Exception as e:
        print("Error during compute_navigation:", e)
        raise

if __name__ == "__main__":
    test_nav()
