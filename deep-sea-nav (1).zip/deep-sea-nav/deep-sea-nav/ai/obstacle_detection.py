from typing import Literal


WarningLevel = Literal["safe", "caution", "danger"]


def evaluate_obstacle_risk(distance_m: float) -> WarningLevel:
    """
    Map obstacle distance to a qualitative warning level.

    Rules:
    - safe:    distance > 100 m
    - caution: 50 m <= distance <= 100 m
    - danger:  distance < 50 m
    """
    if distance_m is None:
        raise ValueError("distance_m must be provided")

    if distance_m > 100.0:
        return "safe"
    if 50.0 <= distance_m <= 100.0:
        return "caution"
    return "danger"


def adjust_heading_for_obstacle(current_heading_deg: float, distance_m: float) -> float:
    """
    Adjust vessel heading based on obstacle distance.

    - If obstacle < 50m (danger): alter course by +30 degrees.
    - If 50m <= obstacle <= 100m (caution): alter by +15 degrees.
    - If >100m: no change.
    Heading is wrapped to [0, 360).
    """
    from math import fmod

    heading = current_heading_deg

    if distance_m < 50.0:
        heading += 30.0
    elif 50.0 <= distance_m <= 100.0:
        heading += 15.0

    wrapped = fmod(heading, 360.0)
    if wrapped < 0:
        wrapped += 360.0
    return wrapped

