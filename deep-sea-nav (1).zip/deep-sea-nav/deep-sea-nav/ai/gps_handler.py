import math
import random
from typing import Dict, List, Tuple

Coordinate = Tuple[float, float]


def parse_coordinates(lat: float | str, lon: float | str) -> Coordinate:
    """
    Parse and validate latitude/longitude pair.
    Accepts either numeric or string values.
    """
    try:
        lat_f = float(lat)
        lon_f = float(lon)
    except (TypeError, ValueError):
        raise ValueError("Latitude and longitude must be numeric values")

    if not (-90.0 <= lat_f <= 90.0):
        raise ValueError("Latitude must be between -90 and 90 degrees")
    if not (-180.0 <= lon_f <= 180.0):
        raise ValueError("Longitude must be between -180 and 180 degrees")

    return lat_f, lon_f


def simulate_sensor_readings() -> Dict[str, float]:
    """
    Generate simulated surface-level sensor data.

    This is purely synthetic and does NOT interface with real hardware.
    """
    # Fixed simulated sensor data instead of random
    obstacle_distance = 120.0  # meters
    speed_knots = 14.5
    heading_deg = 185.0
    wave_height_m = 1.2

    return {
        "obstacle_distance_m": round(obstacle_distance, 2),
        "speed_knots": round(speed_knots, 2),
        "heading_deg": round(heading_deg, 1),
        "wave_height_m": round(wave_height_m, 2),
    }


def simulate_waypoints(count: int = 5) -> List[Dict[str, float]]:
    """
    Generate a small set of random waypoints around a reference point.
    """
    # Deterministic waypoints for consistency
    waypoints = [
        {"lat": 12.0, "lon": 73.0},
        {"lat": 12.1, "lon": 73.2},
        {"lat": 12.3, "lon": 73.5},
        {"lat": 12.5, "lon": 73.8},
        {"lat": 12.8, "lon": 74.0}
    ]
    return waypoints


def haversine_distance_km(a: Coordinate, b: Coordinate) -> float:
    """
    Haversine distance between two GPS coordinates in kilometers.
    """
    lat1, lon1 = map(math.radians, a)
    lat2, lon2 = map(math.radians, b)
    dlat = lat2 - lat1
    dlon = lon2 - lon1

    r = 6371.0  # Earth radius in kilometers
    h = (
        math.sin(dlat / 2) ** 2
        + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    )
    return 2 * r * math.asin(math.sqrt(h))

