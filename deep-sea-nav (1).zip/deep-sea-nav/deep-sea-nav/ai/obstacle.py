import random

def classify_obstacle(distance_meters, uw_distance_meters=150):
    """Classifies obstacle threat level based on distance."""
    if distance_meters > 100:
        result = {
            'level': 'safe',
            'badge': 'SAFE',
            'message': 'No immediate threat detected.',
            'action': 'Maintain current course and speed.'
        }
    elif distance_meters > 50:
        result = {
            'level': 'caution',
            'badge': 'CAUTION',
            'message': 'Obstacle detected in proximity.',
            'action': 'Reduce speed and monitor surroundings.'
        }
    else:
        result = {
            'level': 'danger',
            'badge': 'DANGER',
            'message': 'Collision risk — immediate action required!',
            'action': 'Execute emergency course correction now.'
        }

    # Calculate underwater depth dynamically based on distance slider
    # Heuristic: Closer obstacles are often at different depths or represent 
    # more immediate sensor-ping returns. 
    base_depth = 12.5 # Minimum safety depth
    result['underwater_depth'] = round(base_depth + (uw_distance_meters * 0.15), 1)
    result['uw_nearby'] = uw_distance_meters <= 20

    return result
