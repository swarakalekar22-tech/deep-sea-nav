import math
import heapq
import random

def haversine(lat1, lon1, lat2, lon2):
    """Returns distance in km between two GPS coordinates."""
    R = 6371
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def bearing(lat1, lon1, lat2, lon2):
    """Returns compass bearing in degrees (0-360) from point 1 to point 2."""
    lat1_rad, lat2_rad = math.radians(lat1), math.radians(lat2)
    dlon = math.radians(lon2 - lon1)
    x = math.sin(dlon) * math.cos(lat2_rad)
    y = math.cos(lat1_rad)*math.sin(lat2_rad) - math.sin(lat1_rad)*math.cos(lat2_rad)*math.cos(dlon)
    return (math.degrees(math.atan2(x, y)) + 360) % 360

def astar(grid_size, start, goal, obstacles):
    """A* pathfinding on a grid_size x grid_size grid."""
    blocked = set(map(tuple, obstacles))
    open_heap = []
    heapq.heappush(open_heap, (0, start))
    came_from = {}
    g_score = {start: 0}
    
    def heuristic(a, b):
        return abs(a[0]-b[0]) + abs(a[1]-b[1])
    
    directions = [(0,1),(0,-1),(1,0),(-1,0),(1,1),(1,-1),(-1,1),(-1,-1)]
    
    while open_heap:
        _, current = heapq.heappop(open_heap)
        
        if current == goal:
            path = []
            while current in came_from:
                path.append(list(current))
                current = came_from[current]
            path.append(list(start))
            return list(reversed(path))
            
        for dx, dy in directions:
            nb = (current[0]+dx, current[1]+dy)
            
            if not (0 <= nb[0] < grid_size and 0 <= nb[1] < grid_size):
                continue
            if nb in blocked:
                continue
                
            tg = g_score[current] + 1
            if tg < g_score.get(nb, float('inf')):
                came_from[nb] = current
                g_score[nb] = tg
                f = tg + heuristic(nb, goal)
                heapq.heappush(open_heap, (f, nb))
                
    return [list(start), list(goal)]

def compute_navigation(start_lat, start_lng, end_lat, end_lng, obstacle_distance, uw_obstacle_distance=150):
    """Main AI function: returns full navigation result dict."""
    import logging
    logger = logging.getLogger(__name__)
    
    from ai.obstacle import classify_obstacle
    dist_km   = haversine(start_lat, start_lng, end_lat, end_lng)
    hdg       = bearing(start_lat, start_lng, end_lat, end_lng)
    eta_mins  = round((dist_km / (12 * 1.852)) * 60)
    
    logger.info(f"Calc: Dist={dist_km:.2f}km, HDG={hdg:.1f}, ETA={eta_mins}min")
    
    obs = classify_obstacle(obstacle_distance, uw_obstacle_distance)
    logger.info(f"Obstacle check: {obs['level']} (Surface Dist={obstacle_distance}m, UW Dist={uw_obstacle_distance}m)")
    
    # Use deterministic obstacles on 20x20 grid for stability
    grid_size = 20
    obstacles = {(5, 5), (15, 15), (5, 15), (15, 5)}
        
    if obs['level'] != 'safe':
        obstacles.add((10, 10))
    
    path = astar(grid_size, (0,0), (grid_size-1, grid_size-1), obstacles)
    
    underwater_obstacles = []
    if 'underwater_depth' in obs:
        # Place an underwater obstacle on the grid
        underwater_obstacles.append([11, 11])

    # Calculate geographic marine route avoiding land
    try:
        import searoute
        import logging
        logger = logging.getLogger(__name__)
        logger.info(f"Computing route from [{start_lat}, {start_lng}] to [{end_lat}, {end_lng}]")
        
        route = searoute.searoute([start_lng, start_lat], [end_lng, end_lat])
        actual_route = [[c[1], c[0]] for c in route['geometry']['coordinates']]
        logger.info(f"Route calculated with {len(actual_route)} waypoints")
    except Exception as e:
        import logging
        logger = logging.getLogger(__name__)
        logger.warning(f"Searoute API Error: {e}. Falling back to straight line.")
        # Fallback to straight line
        actual_route = [[start_lat, start_lng], [end_lat, end_lng]]


    import datetime
    
    # Calculate SOG (Speed Over Ground) based on nearby obstacle level
    # 1. Danger (< 50m): Execute emergency slow-down (3.5 knots)
    # 2. Caution (< 100m): Precautionary slow-down (7.2 knots)
    # 3. Safe (> 100m): Normal transit (12.0 knots)
    if obs['level'] == 'danger':
        sog = 3.5
    elif obs['level'] == 'caution':
        sog = 7.2
    else:
        sog = 12.0
    
    # Recalculate ETA based on current speed
    eta_mins = round((dist_km / (sog * 1.852)) * 60) if sog > 0 else 0

    # STW is Speed Through Water (including current factor ~ 0.9 of SOG)
    stw = round(sog * 0.9, 1)
    
    # Base depth logic slightly varies based on distance for AI visual variety
    depth_meters = round(45.0 + (obstacle_distance * 0.08), 1)
    
    return {
        'heading_degrees': round(hdg, 1),
        'distance_km': round(dist_km, 2),
        'eta_minutes': int(eta_mins),
        'bearing_degrees': round(hdg, 1),
        'sog_knots': sog,
        'stw_knots': stw,
        'stwKnots': stw,
        'stw': stw,
        'time_str': datetime.datetime.now().strftime('%H:%M:%S'),
        'cog_degrees': round(hdg, 1),
        'depth_meters': depth_meters,
        'obstacle': obs,
        'route_waypoints': path,
        'grid_obstacles': [list(o) for o in obstacles],
        'underwater_obstacles': underwater_obstacles,
        'grid_size': grid_size,
        'actual_route': actual_route
    }
