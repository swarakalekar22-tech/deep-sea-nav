from ai.navigation import compute_navigation
import json

def test_nav_empty():
    try:
        print("Testing compute_navigation with strings...")
        # Simulating what might be passed from app.py if it failed logic
        result = compute_navigation("", "", "", "", "", "")
        print("Success!")
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    test_nav_empty()
