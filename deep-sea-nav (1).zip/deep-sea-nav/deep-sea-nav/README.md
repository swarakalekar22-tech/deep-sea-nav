# AI-Based Deep-Sea Navigation System (DeepNav AI)

An AI-powered **surface navigation** demo built with Python (Flask) and a modern single-page website UI. The system simulates GPS-based routing, surface-level obstacle detection, and an AI navigation engine that computes headings and routes in real time.

> **Important scope note:** This project models **surface-only** navigation. It does **not** perform any underwater mapping, depth estimation, or bathymetric analysis.

---

## What This Project Does

- **Surface GPS Navigation** – Simulated coordinates and waypoints to represent vessel position and targets.
- **Surface Obstacle Detection** – Distance-based warning levels: `safe`, `caution`, and `danger`.
- **AI Navigation Logic** – A* pathfinding on a grid, heading calculation between GPS points, and simple route optimization.
- **Interactive Web UI** – Dark, ocean-themed website with sections for About, Architecture, Features, Applications, Tech Stack, AI System, and a Live Demo.
- **Live Simulator** – Canvas-based vessel simulator that animates a surface route on a 20x20 grid.

### What It Does *Not* Do

- No underwater obstacle detection
- No depth / seafloor mapping
- No real hardware integration (all sensors & GPS data are simulated)

---

## Tech Stack

- **Frontend:** HTML, CSS, JavaScript, Chart.js
- **Backend:** Python, Flask
- **AI / Data:** NumPy, (demonstration-friendly structure for Pandas / scikit-learn)

---

## Setup & Running Locally

1. **Clone or create the project folder**

   ```bash
   cd deep-sea-nav
   ```

2. **Create a virtual environment** (optional but recommended)

   ```bash
   python -m venv .venv
   .venv\Scripts\activate  # Windows PowerShell
   ```

3. **Install dependencies**

   ```bash
   pip install -r requirements.txt
   ```

4. **Run the Flask app**

   ```bash
   python app.py
   ```

5. **Open the app in your browser**

   Visit `http://127.0.0.1:5000` (or `http://localhost:5000`).

---

## API Endpoints

### `GET /`

Serve the main single-page website (`templates/index.html`).

---

### `POST /api/navigate`

Run the AI navigation pipeline:

- **Input JSON:**

  ```json
  {
    "start_lat": 12.9,
    "start_lon": 73.8,
    "dest_lat": 13.1,
    "dest_lon": 73.95,
    "obstacle_distance": 80.0
  }
  ```

- **Output JSON (example):**

  ```json
  {
    "start": { "lat": 12.9, "lon": 73.8 },
    "end": { "lat": 13.1, "lon": 73.95 },
    "grid_route": [{ "x": 1, "y": 10 }, { "x": 2, "y": 10 }, "..."],
    "heading_degrees": 42.5,
    "obstacle_distance_m": 80.0,
    "obstacle_status": "caution"
  }
  ```

---

### `POST /api/detect-obstacle`

Classify surface obstacle risk by distance.

- **Input JSON:**

  ```json
  { "distance": 45.0 }
  ```

- **Output JSON:**

  ```json
  {
    "distance_m": 45.0,
    "status": "danger"
  }
  ```

Rules:

- `safe` if distance &gt; 100 m  
- `caution` if 50–100 m  
- `danger` if &lt; 50 m

---

### `GET /api/simulate-sensors`

Return randomized surface sensor readings for dashboard / demo use.

- **Example Output:**

  ```json
  {
    "obstacle_distance_m": 132.5,
    "speed_knots": 12.7,
    "heading_deg": 214.3,
    "wave_height_m": 1.24
  }
  ```

---

### `POST /api/optimize-route`

Optimize a sequence of GPS waypoints using a nearest-neighbor heuristic.

- **Input JSON:**

  ```json
  {
    "waypoints": [
      { "lat": 12.9, "lon": 73.8 },
      { "lat": 13.2, "lon": 73.6 },
      { "lat": 13.0, "lon": 74.1 }
    ]
  }
  ```

  If omitted, the backend will simulate a small set of waypoints automatically.

- **Output JSON (example):**

  ```json
  {
    "optimized_order_indices": [0, 2, 1],
    "optimized_waypoints": [
      { "lat": 12.9, "lon": 73.8, "original_index": 0 },
      { "lat": 13.0, "lon": 74.1, "original_index": 2 },
      { "lat": 13.2, "lon": 73.6, "original_index": 1 }
    ]
  }
  ```

---

## Project Structure

```text
deep-sea-nav/
├── app.py
├── requirements.txt
├── static/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── main.js
│   └── assets/
│       └── (placeholder assets)
├── templates/
│   └── index.html
├── ai/
│   ├── __init__.py
│   ├── navigation.py
│   ├── obstacle_detection.py
│   └── gps_handler.py
└── README.md
```

---

## Screenshots

Add screenshots of:

- The hero + navigation sections
- The AI System panel with mini-map
- The Live Demo simulator in action

(Place your screenshots in `static/assets/` and reference them here.)

---

## License

This project is intended as a **portfolio / demo** for an AI-based surface navigation concept. Adapt and extend it as needed for your own learning or showcase.

