from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
from ai.navigation import compute_navigation
from ai.obstacle import classify_obstacle
import webbrowser
import threading
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)


app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
CORS(app)

@app.route('/')
def index():
    """Serves the main application page."""
    return render_template('index.html')

@app.route('/api/navigate', methods=['POST'])
def navigate():
    """Endpoint for AI navigation computation."""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
            
        logger.info(f"Received navigation request: {data}")
        
        def get_float(key, default):
            try:
                val = data.get(key)
                if val is None or str(val).strip() == "":
                    return default
                return float(val)
            except:
                return default
                
        start_lat = get_float('start_lat', 19.0760)
        start_lng = get_float('start_lng', 72.8777)
        end_lat   = get_float('end_lat', 15.2993)
        end_lng   = get_float('end_lng', 74.1240)
        obstacle_distance = get_float('obstacle_distance', 120)
        uw_obstacle_distance = get_float('uw_obstacle_distance', 150)
        
        logger.info(f"Computing navigation: From ({start_lat}, {start_lng}) To ({end_lat}, {end_lng})")
        
        result = compute_navigation(start_lat, start_lng, end_lat, end_lng, obstacle_distance, uw_obstacle_distance)
        logger.info("Navigation computation successful")
        return jsonify(result)

    except Exception as e:
        logger.error(f"Navigation Error: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 400


@app.route('/api/detect-obstacle', methods=['POST'])
def detect_obstacle():
    """Endpoint for manual obstacle classification."""
    try:
        data = request.get_json()
        distance = float(data.get('distance_meters', 100))
        result = classify_obstacle(distance)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint."""
    return jsonify({
        'status': 'ok', 
        'message': 'DeepNav AI Backend Running'
    })

if __name__ == '__main__':
    def open_browser():
        webbrowser.open('http://localhost:5000')
    
    # Use a timer to wait for the server to start before opening browser
    threading.Timer(1.2, open_browser).start()
    
    # debug=True is helpful for development and troubleshooting
    app.run(debug=True, port=5000)
