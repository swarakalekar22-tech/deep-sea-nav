// --- Global Error Monitoring ---
window.onerror = function(msg, url, line, col, error) {
    console.error(`[DeepNav-Global] Error: ${msg} at ${url}:${line}:${col}`, error);
    return false; // Let browser handle it as well
};

document.addEventListener('DOMContentLoaded', () => {
    console.log('[DeepNav] DOM Content Loaded. Initializing systems...');

    // --- Navbar Scroll Effect ---
    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    // --- Mobile Hamburger ---
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    hamburger.addEventListener('click', () => {
        navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
    });

    // --- Interaction Observer for Animations ---
    const observerOptions = {
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                // If it's a tech bar, trigger fill animation is handled by CSS
            }
        });
    }, observerOptions);

    document.querySelectorAll('[data-animate]').forEach(el => observer.observe(el));

    // --- Hero Sonar Animation ---
    initHeroCanvas();

    // --- AI System Panel Features ---
    initAISystem();
    
    // --- Leaflet Map ---
    initWorldMap();
});



/**
 * Hero Section Animated Sonar
 */
function initHeroCanvas() {
    const canvas = document.getElementById('hero-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    
    let width, height;
    function resize() {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resize);
    resize();

    let angle = 0;
    const pings = [];
    const particles = [];

    // Create persistent particles
    for (let i = 0; i < 80; i++) {
        particles.push({
            x: Math.random() * width,
            y: Math.random() * height,
            size: Math.random() * 2,
            speed: Math.random() * 0.5 + 0.1,
            opacity: Math.random() * 0.5
        });
    }

    function animate() {
        ctx.clearRect(0, 0, width, height);
        
        const centerX = width / 2;
        const centerY = height / 2;
        const maxRadius = Math.max(width, height) * 0.7;

        // Draw static grid rings
        ctx.strokeStyle = 'rgba(0, 212, 255, 0.05)';
        ctx.lineWidth = 1;
        for (let r = 100; r < maxRadius; r += 200) {
            ctx.beginPath();
            ctx.arc(centerX, centerY, r, 0, Math.PI * 2);
            ctx.stroke();
        }

        // Crosshairs
        ctx.beginPath();
        ctx.moveTo(centerX - 50, centerY);
        ctx.lineTo(centerX + 50, centerY);
        ctx.moveTo(centerX, centerY - 50);
        ctx.lineTo(centerX, centerY + 50);
        ctx.stroke();

        // Scan Line
        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.rotate(angle);
        
        const gradient = ctx.createLinearGradient(0, 0, maxRadius, 0);
        gradient.addColorStop(0, 'rgba(0, 212, 255, 0.3)');
        gradient.addColorStop(1, 'rgba(0, 212, 255, 0)');
        
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, maxRadius, -0.2, 0.2);
        ctx.fill();
        
        ctx.strokeStyle = 'rgba(0, 212, 255, 0.4)';
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(maxRadius, 0);
        ctx.stroke();
        ctx.restore();

        angle += 0.01;

        // Pings
        if (Math.random() < 0.01) {
            pings.push({ r: 0, opacity: 0.8 });
        }

        for (let i = pings.length - 1; i >= 0; i--) {
            const p = pings[i];
            p.r += 2;
            p.opacity -= 0.005;
            
            if (p.opacity <= 0) {
                pings.splice(i, 1);
                continue;
            }

            ctx.strokeStyle = `rgba(0, 212, 255, ${p.opacity})`;
            ctx.beginPath();
            ctx.arc(centerX, centerY, p.r, 0, Math.PI * 2);
            ctx.stroke();
        }

        // Particles
        particles.forEach(p => {
            p.y -= p.speed;
            if (p.y < 0) p.y = height;
            
            ctx.fillStyle = `rgba(232, 244, 248, ${p.opacity})`;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        });

        requestAnimationFrame(animate);
    }
    animate();
}

/**
 * Navigation AI System Integration
 */
function initAISystem() {
    console.log('[DeepNav] Initializing AI System Panel...');
    const computeBtn = document.getElementById('compute-btn');
    if (!computeBtn) {
        console.warn('[DeepNav] Warning: #compute-btn not found in DOM.');
        return;
    }

    const obsDistInput = document.getElementById('obs-dist');
    const obsDistVal = document.getElementById('obs-dist-val');
    const uwObsDistInput = document.getElementById('uw-obs-dist');
    const uwObsDistVal = document.getElementById('uw-obs-dist-val');
    const boardUwWarning = document.getElementById('board-uw-warning');
    const boardUwDepth = document.getElementById('board-uw-depth');

    // Surface obstacle slider live update
    if (obsDistInput && obsDistVal) {
        obsDistInput.addEventListener('input', () => {
            obsDistVal.textContent = obsDistInput.value + 'm';
        });
    }


    // Underwater obstacle slider — show warning panel and reset depth when slider moves
    if (uwObsDistInput) {
        uwObsDistInput.addEventListener('input', () => {
            uwObsDistVal.textContent = uwObsDistInput.value + 'm';
            if (parseInt(uwObsDistInput.value) <= 20) {
                if (boardUwWarning) boardUwWarning.style.display = 'block';
                if (boardUwDepth) boardUwDepth.textContent = '??';
            } else {
                if (boardUwWarning) boardUwWarning.style.display = 'none';
                if (boardUwDepth) boardUwDepth.textContent = '--';
            }
        });
    }

    computeBtn.addEventListener('click', runAI);
}

function setPreset(type) {
    const lat1 = document.getElementById('start-lat');
    const lng1 = document.getElementById('start-lng');
    const lat2 = document.getElementById('end-lat');
    const lng2 = document.getElementById('end-lng');

    if (type === 'mumbai-goa') {
        lat1.value = "19.0760"; lng1.value = "72.8777";
        lat2.value = "15.2993"; lng2.value = "74.1240";
    } else if (type === 'gulf') {
        lat1.value = "25.2048"; lng1.value = "55.2708";
        lat2.value = "17.0506"; lng2.value = "54.1066";
    } else if (type === 'malacca') {
        lat1.value = "1.2902"; lng1.value = "103.8519";
        lat2.value = "5.4141"; lng2.value = "100.3288";
        // Auto-set hazardous underwater distance
        const uwDist = document.getElementById('uw-obs-dist');
        const uwVal = document.getElementById('uw-obs-dist-val');
        if (uwDist) {
            uwDist.value = 18;
            if (uwVal) uwVal.textContent = "18m";
            uwDist.dispatchEvent(new Event('input'));
        }
    } else if (type === 'suez') {
        lat1.value = "29.9667"; lng1.value = "32.5500";
        lat2.value = "31.2667"; lng2.value = "32.3333";
        // Auto-set hazardous underwater distance
        const uwDist = document.getElementById('uw-obs-dist');
        const uwVal = document.getElementById('uw-obs-dist-val');
        if (uwDist) {
            uwDist.value = 15;
            if (uwVal) uwVal.textContent = "15m";
            uwDist.dispatchEvent(new Event('input'));
        }
    }
}

async function runAI() {
    console.log('[DeepNav] runAI triggered.');
    const loading = document.getElementById('ai-loading');
    const results = document.getElementById('ai-results');
    
    if (!loading || !results) {
        console.error('[DeepNav] Critical: AI UI elements missing (#ai-loading or #ai-results)');
        return;
    }

    loading.style.display = 'flex';
    results.style.opacity = '0.3';
    
    // Elite UI: Add Log Entry
    if (typeof addLogEntry === 'function') {
        addLogEntry('INITIATING NAVIGATION COMPUTE SEQUENCE...');
        addLogEntry('ESTABLISHING SAT-LINK TO GPS CONSTELLATION...');
    }

    try {
        const startLatEl = document.getElementById('start-lat');
        const startLngEl = document.getElementById('start-lng');
        const endLatEl   = document.getElementById('end-lat');
        const endLngEl   = document.getElementById('end-lng');
        const obsDistEl  = document.getElementById('obs-dist');
        const uwObsDistEl = document.getElementById('uw-obs-dist');

        if (!startLatEl || !startLngEl || !endLatEl || !endLngEl || !obsDistEl) {
            throw new Error('Required input fields (lat/lng/dist) are missing from the DOM.');
        }

        const payload = {
            start_lat: startLatEl.value,
            start_lng: startLngEl.value,
            end_lat:   endLatEl.value,
            end_lng:   endLngEl.value,
            obstacle_distance: obsDistEl.value,
            uw_obstacle_distance: uwObsDistEl ? uwObsDistEl.value : 150
        };

        console.log('[DeepNav] Sending navigation payload:', payload);

        const response = await fetch('/api/navigate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        
        console.log('[DeepNav] Fetch response received. Status:', response.status);
        
        if (!response.ok) {
            const errData = await response.json().catch(() => ({}));
            console.error('[DeepNav] API error data:', errData);
            throw new Error(errData.error || `Server returned ${response.status}`);
        }
        
        const data = await response.json();
        console.log('[DeepNav] Navigation computation successful. Received keys:', Object.keys(data));
        renderAIResults(data);
        
        // Elite UI: Success Log
        if (typeof addLogEntry === 'function') {
            addLogEntry('ROUTE COMPUTATION SUCCESSFUL. EXPORTING TO HUD...');
            addLogEntry(`BEARING: ${data.bearing_degrees}° | SOG: ${data.sog_knots} kts | DIST: ${data.distance_km} km`);
        }
    } catch (err) {
        console.error("[DeepNav] AI Computation Error:", err);
        if (typeof addLogEntry === 'function') {
            addLogEntry(`CRITICAL ERROR: ${err.message}`);
        }
        alert(`DeepNav Error: ${err.message || 'Failed to compute navigation.'}`);
    } finally {
        loading.style.display = 'none';
        results.style.opacity = '1';
    }
}

// --- Elite UI Utility Functions ---
window.addEventListener('scroll', () => {
    const scrollHUD = document.getElementById('scroll-hud');
    if (scrollHUD) {
        const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
        const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (winScroll / height) * 100;
        scrollHUD.style.width = scrolled + "%";
    }
});

function addLogEntry(message) {
    const log = document.getElementById('tactical-log');
    if (log) {
        const entry = document.createElement('div');
        entry.className = 'log-entry';
        entry.style.marginBottom = '4px';
        entry.textContent = `> ${new Date().toLocaleTimeString()} - ${message}`;
        log.appendChild(entry);
        log.scrollTop = log.scrollHeight;
        
        // Limit log entries
        if (log.children.length > 20) log.removeChild(log.firstChild);
    }
}


function renderAIResults(data) {
    console.log('[DeepNav] Starting renderAIResults...');
    // 1. Update Primary Summary Grid
    const updateText = (id, val) => {
        const el = document.getElementById(id);
        if (el) {
            el.textContent = val;
            return true;
        }
        console.warn(`[DeepNav] Warning: Element #${id} not found.`);
        return false;
    };

    updateText('res-heading', data.heading_degrees + '°');
    updateText('res-bearing', data.bearing_degrees + '°');
    updateText('res-cog', data.cog_degrees + '°');
    updateText('res-sog', data.sog_knots + ' kts');
    
    if (document.getElementById('res-stw')) {
        let val = '--';
        if (data.stw_knots !== undefined) val = data.stw_knots;
        else if (data.stwKnots !== undefined) val = data.stwKnots;
        else if (data.stw !== undefined) val = data.stw;
        document.getElementById('res-stw').textContent = val + ' kts';
    }

    updateText('res-depth', data.depth_meters + ' m');
    updateText('res-time', data.time_str);
    updateText('res-dist', data.distance_km + ' km');
    updateText('res-eta', data.eta_minutes + ' min');

    // 2. Update Map HUD Overlay (Removed)

    console.log('[DeepNav] AI computation results v7:', data);
    
    const badge = document.getElementById('res-badge');
    const box = document.getElementById('threat-box');
    const msg = document.getElementById('res-msg');
    const action = document.getElementById('res-action');
    const obsDepth = document.getElementById('res-obs-depth');
    const obsDepthContainer = document.getElementById('res-obs-depth-container');

    if (badge) {
        badge.className = 'threat-badge ' + data.obstacle.level;
        badge.textContent = data.obstacle.badge;
    }
    if (box) box.className = 'threat-display ' + data.obstacle.level;
    if (msg) msg.textContent = data.obstacle.message;
    if (action) action.textContent = data.obstacle.action;

    const obsDepthGrid   = document.getElementById('res-obs-depth-grid');
    const boardUwDepth   = document.getElementById('board-uw-depth');
    const boardUwWarning = document.getElementById('board-uw-warning');

    console.log('[DeepNav] obstacle data:', data.obstacle);

    // underwater_depth is always returned — display it everywhere
    const uwDepth = data.obstacle.underwater_depth;

    // Summary grid tile — always visible
    if (obsDepthGrid) obsDepthGrid.textContent = uwDepth !== undefined ? `${uwDepth} m` : '-- m';

    // Threat-box detailed warning block — always visible
    if (obsDepthContainer) {
        if (obsDepth) obsDepth.textContent = `Depth: ${uwDepth} m`;
        obsDepthContainer.style.display = 'block';
    }

    // Input-panel inline warning — only show when within 20m proximity
    if (data.obstacle.uw_nearby) {
        if (boardUwDepth)   boardUwDepth.textContent    = uwDepth;
        if (boardUwWarning) boardUwWarning.style.display = 'block';
        // Add it to the message too with strong visibility
        if (msg) {
            msg.innerHTML = `⚠️ <b>${data.obstacle.message}</b> <br/> [U/W Depth: <span style="color:#ff3366">${uwDepth}m</span>]`;
        }
    } else {
        if (boardUwDepth)   boardUwDepth.textContent    = uwDepth !== undefined ? uwDepth : '--';
        if (boardUwWarning) boardUwWarning.style.display = 'none';
    }

    drawWorldMap(data);
}

// --- Leaflet World Map Control ---
let worldMap = null;
let worldRouteLine = null;
let startMarker = null;
let endMarker = null;
let vesselMarker = null;
let infrastructureLayer = null;

function getFishingActivityData() {
    return {
        "type": "FeatureCollection",
        "features": [
            { "type": "Feature", "properties": { "name": "Grand Banks", "gear": "Trawling / Longline", "risk": "High (Fog & Icebergs)" }, "geometry": { "type": "Point", "coordinates": [-50.99, 45.23] } },
            { "type": "Feature", "properties": { "name": "North Sea Industrial Grounds", "gear": "Bottom Trawling", "risk": "Medium (High Traffic)" }, "geometry": { "type": "Point", "coordinates": [3.00, 56.40] } },
            { "type": "Feature", "properties": { "name": "Malacca Artisanal Zone", "gear": "Small Craft / Gillnets", "risk": "Expert (Unpredictable)" }, "geometry": { "type": "Point", "coordinates": [99.55, 4.40] } },
            { "type": "Feature", "properties": { "name": "West Coast India (Gujarat/Maharashtra)", "gear": "Trawlers / Purse Seine", "risk": "Moderate (Seasonal)" }, "geometry": { "type": "Point", "coordinates": [72.40, 19.50] } },
            { "type": "Feature", "properties": { "name": "Western Saharan Shelf", "gear": "Industrial Cephalopod", "risk": "High (Upwelling)" }, "geometry": { "type": "Point", "coordinates": [-13.00, 24.50] } },
            { "type": "Feature", "properties": { "name": "Yellow Sea Common Zone", "gear": "Large Scale Commercial", "risk": "Very High (Congestion)" }, "geometry": { "type": "Point", "coordinates": [123.50, 35.50] } }
        ]
    };
}

function renderFishingIcon() {
    return `
        <svg class="fishing-icon-svg" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 18L2 14H22L20 18H4Z" fill="#e67e22"/>
            <path d="M12 4V12" stroke="#e67e22" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M12 6L16 10" stroke="#e67e22" stroke-width="1.5" stroke-linecap="round"/>
            <circle cx="12" cy="14" r="1.5" fill="#fff"/>
        </svg>
        <div class="fishing-label">FISH</div>
    `;
}

function getDepthContourData() {
    return {
        "type": "FeatureCollection",
        "features": [
            // MUMBAI (Existing)
            { "type": "Feature", "properties": { "depth": 5, "name": "5m Safety Contour" }, "geometry": { "type": "LineString", "coordinates": [[72.82, 18.92], [72.84, 18.90], [72.86, 18.88], [72.88, 18.84]] } },
            { "type": "Feature", "properties": { "depth": 10, "name": "10m Contour" }, "geometry": { "type": "LineString", "coordinates": [[72.78, 18.94], [72.80, 18.92], [72.82, 18.90], [72.84, 18.86]] } },
            
            // MALACCA / SINGAPORE (NEW)
            { "type": "Feature", "properties": { "depth": 10, "name": "10m Singapore Shoal" }, "geometry": { "type": "LineString", "coordinates": [[103.85, 1.22], [103.95, 1.18], [104.05, 1.15]] } },
            
            // ENGLISH CHANNEL (NEW)
            { "type": "Feature", "properties": { "depth": 20, "name": "20m Dover Shelf" }, "geometry": { "type": "LineString", "coordinates": [[1.30, 51.05], [1.45, 51.00], [1.60, 50.95]] } }
        ]
    };
}

function getDepthSoundingPoints() {
    return {
        "type": "FeatureCollection",
        "features": [
            { "type": "Feature", "properties": { "depth": 14.5 }, "geometry": { "type": "Point", "coordinates": [72.81, 18.91] } },
            { "type": "Feature", "properties": { "depth": 12.2 }, "geometry": { "type": "Point", "coordinates": [72.83, 18.89] } },
            
            // SUEZ (NEW)
            { "type": "Feature", "properties": { "depth": 15.1 }, "geometry": { "type": "Point", "coordinates": [32.33, 31.30] } },
            
            // MALACCA (NEW)
            { "type": "Feature", "properties": { "depth": 22.4 }, "geometry": { "type": "Point", "coordinates": [103.75, 1.20] } },

            // DOVER (NEW)
            { "type": "Feature", "properties": { "depth": 28.5 }, "geometry": { "type": "Point", "coordinates": [1.40, 51.02] } },

            // PANAMA (NEW)
            { "type": "Feature", "properties": { "depth": 16.8 }, "geometry": { "type": "Point", "coordinates": [-79.52, 8.88] } }
        ]
    };
}

function getBottomNatureData() {
    return {
        "type": "FeatureCollection",
        "features": [
            // MUMBAI ANCHORAGE
            { "type": "Feature", "properties": { "abbr": "M", "desc": "Mud (Soft Holding Ground)" }, "geometry": { "type": "Point", "coordinates": [72.86, 18.89] } },
            { "type": "Feature", "properties": { "abbr": "S", "desc": "Sand (Good Holding Ground)" }, "geometry": { "type": "Point", "coordinates": [72.84, 18.91] } },
            
            // ENGLISH CHANNEL (NEW)
            { "type": "Feature", "properties": { "abbr": "R", "desc": "Rock (Foul Ground)" }, "geometry": { "type": "Point", "coordinates": [1.45, 51.08] } },
            { "type": "Feature", "properties": { "abbr": "Sn", "desc": "Shingle/Gravel" }, "geometry": { "type": "Point", "coordinates": [1.50, 51.15] } },

            // STRAIT OF HORMUZ (NEW)
            { "type": "Feature", "properties": { "abbr": "S", "desc": "Fine Sand" }, "geometry": { "type": "Point", "coordinates": [56.45, 26.25] } },

            // SUEZ APPROACH
            { "type": "Feature", "properties": { "abbr": "S", "desc": "Fine Sand" }, "geometry": { "type": "Point", "coordinates": [32.35, 31.25] } }
        ]
    };
}

function getNauticalHazardData() {
    return {
        "type": "FeatureCollection",
        "features": [
            // MUMBAI (Clusters)
            { "type": "Feature", "properties": { "type": "rock", "name": "Prongs Rock (Awash)", "depth": "0.2m" }, "geometry": { "type": "Point", "coordinates": [72.82, 18.88] } },
            { "type": "Feature", "properties": { "type": "wreck", "name": "Submerged Wreck (SS DeepNav)", "depth": "8.5m" }, "geometry": { "type": "Point", "coordinates": [72.85, 18.83] } },
            { "type": "Feature", "properties": { "type": "obstn", "name": "Mumbai Outer Obstr.", "depth": "11.2m" }, "geometry": { "type": "Point", "coordinates": [72.80, 18.85] } },
            { "type": "Feature", "properties": { "type": "wreck", "name": "Historical Barge Wreck", "depth": "14.0m" }, "geometry": { "type": "Point", "coordinates": [72.88, 18.80] } },
            
            // SUEZ CANAL & RED SEA (Graveyard of Ships)
            { "type": "Feature", "properties": { "type": "wreck", "name": "SS Thistlegorm Wreck", "depth": "30.0m" }, "geometry": { "type": "Point", "coordinates": [33.92, 27.81] } },
            { "type": "Feature", "properties": { "type": "wreck", "name": "Giannis D Wreck", "depth": "24.0m" }, "geometry": { "type": "Point", "coordinates": [33.93, 27.58] } },
            { "type": "Feature", "properties": { "type": "wreck", "name": "Carnatic Wreck", "depth": "22.0m" }, "geometry": { "type": "Point", "coordinates": [33.94, 27.59] } },
            { "type": "Feature", "properties": { "type": "rock", "name": "Shab Abu Nuhas Reef", "depth": "0.0m" }, "geometry": { "type": "Point", "coordinates": [33.91, 27.57] } },
            { "type": "Feature", "properties": { "type": "obstn", "name": "Ras Mohammed Submerged Pipes", "depth": "12.5m" }, "geometry": { "type": "Point", "coordinates": [34.25, 27.75] } },

            // MALACCA STRAIT & SINGAPORE (Dense Hazards)
            { "type": "Feature", "properties": { "type": "wreck", "name": "WWII Destroyer Wreck", "depth": "18.2m" }, "geometry": { "type": "Point", "coordinates": [103.85, 1.25] } },
            { "type": "Feature", "properties": { "type": "wreck", "name": "Sunk Tanker (1984)", "depth": "28.0m" }, "geometry": { "type": "Point", "coordinates": [103.92, 1.18] } },
            { "type": "Feature", "properties": { "type": "obstn", "name": "Singapore Dredging Obstr.", "depth": "3.8m" }, "geometry": { "type": "Point", "coordinates": [103.95, 1.15] } },
            { "type": "Feature", "properties": { "type": "rock", "name": "Batu Puteh Complex", "depth": "0.5m" }, "geometry": { "type": "Point", "coordinates": [104.40, 1.33] } },
            { "type": "Feature", "properties": { "type": "wreck", "name": "Unidentified Fishing Wreck", "depth": "9.1m" }, "geometry": { "type": "Point", "coordinates": [103.78, 1.12] } },

            // ENGLISH CHANNEL & DOVER STRAIT (Wreck Alley)
            { "type": "Feature", "properties": { "type": "wreck", "name": "Varne Bank Cluster A", "depth": "12.0m" }, "geometry": { "type": "Point", "coordinates": [1.45, 51.05] } },
            { "type": "Feature", "properties": { "type": "wreck", "name": "Varne Bank Cluster B", "depth": "14.5m" }, "geometry": { "type": "Point", "coordinates": [1.47, 51.04] } },
            { "type": "Feature", "properties": { "type": "obstn", "name": "Goodwin Sands North Obstr.", "depth": "2.1m" }, "geometry": { "type": "Point", "coordinates": [1.55, 51.27] } },
            { "type": "Feature", "properties": { "type": "wreck", "name": "Dover Outer Wreckage", "depth": "19.0m" }, "geometry": { "type": "Point", "coordinates": [1.65, 51.12] } },

            // STRAIT OF HORMUZ & PERSIAN GULF
            { "type": "Feature", "properties": { "type": "rock", "name": "Quoin Island Rocks", "depth": "0.1m" }, "geometry": { "type": "Point", "coordinates": [56.52, 26.51] } },
            { "type": "Feature", "properties": { "type": "wreck", "name": "Gulf Tanker Wreck", "depth": "25.0m" }, "geometry": { "type": "Point", "coordinates": [55.10, 25.45] } },
            { "type": "Feature", "properties": { "type": "wreck", "name": "Submerged Tugboat", "depth": "18.0m" }, "geometry": { "type": "Point", "coordinates": [56.10, 26.35] } },

            // PANAMA CANAL (Pacific Approach)
            { "type": "Feature", "properties": { "type": "obstn", "name": "Flamenco Is. Pile Cluster", "depth": "6.2m" }, "geometry": { "type": "Point", "coordinates": [-79.52, 8.91] } },
            { "type": "Feature", "properties": { "type": "rock", "name": "Taboga Island Reclining Rock", "depth": "1.0m" }, "geometry": { "type": "Point", "coordinates": [-79.55, 8.80] } },
            { "type": "Feature", "properties": { "type": "wreck", "name": "Old Panama Patrol Wreck", "depth": "12.5m" }, "geometry": { "type": "Point", "coordinates": [-79.48, 8.85] } }
        ]
    };
}

function renderHazardSymbol(type) {
    let svgContent = '';
    let label = '';
    const hazardColor = '#e91e63'; // High-visibility Magenta

    if (type === 'rock') {
        // Rock Awash: Circle with Cross
        svgContent = `
            <circle cx="12" cy="12" r="6" stroke="${hazardColor}" stroke-width="2" fill="none" class="hazard-svg"/>
            <line x1="8" y1="12" x2="16" y2="12" stroke="${hazardColor}" stroke-width="2"/>
            <line x1="12" y1="8" x2="12" y2="16" stroke="${hazardColor}" stroke-width="2"/>
        `;
    } else if (type === 'wreck') {
        // Submerged Wreck: Dotted Circle with Cross + WK
        svgContent = `
            <circle cx="12" cy="12" r="8" stroke="${hazardColor}" stroke-width="1.5" stroke-dasharray="2,2" fill="none" class="hazard-svg"/>
            <line x1="6" y1="6" x2="18" y2="18" stroke="${hazardColor}" stroke-width="2"/>
            <line x1="18" y1="6" x2="6" y2="18" stroke="${hazardColor}" stroke-width="2"/>
        `;
        label = '<div class="hazard-wk">WK</div>';
    } else if (type === 'obstn') {
        // Obstruction: Circle with Sticks
        svgContent = `
            <circle cx="12" cy="12" r="7" stroke="${hazardColor}" stroke-width="1.5" stroke-dasharray="2,2" fill="none" class="hazard-svg"/>
            <line x1="12" y1="4" x2="12" y2="10" stroke="${hazardColor}" stroke-width="2"/>
            <line x1="8" y1="14" x2="8" y2="20" stroke="${hazardColor}" stroke-width="2"/>
            <line x1="16" y1="14" x2="16" y2="20" stroke="${hazardColor}" stroke-width="2"/>
        `;
    }

    return `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">${svgContent}</svg>${label}`;
}

function getSafetyShadingData() {
    return {
        "type": "FeatureCollection",
        "features": [
            // MUMBAI (Existing)
            { "type": "Feature", "properties": { "name": "Mumbai Safety Shelf", "risk": "High" }, 
              "geometry": { "type": "Polygon", "coordinates": [[[72.82, 18.95], [72.90, 18.95], [72.90, 18.82], [72.82, 18.82], [72.82, 18.95]]] } },

            // SUEZ APPROACH (NEW)
            { "type": "Feature", "properties": { "name": "Port Said Shallow Shelf", "risk": "High" }, 
              "geometry": { "type": "Polygon", "coordinates": [[[32.25, 31.35], [32.45, 31.35], [32.45, 31.20], [32.25, 31.20], [32.25, 31.35]]] } },

            // SINGAPORE STRAIT (NEW)
            { "type": "Feature", "properties": { "name": "Singapore Hazard Zone", "risk": "Expert Only" }, 
              "geometry": { "type": "Polygon", "coordinates": [[[103.80, 1.25], [104.10, 1.25], [104.10, 1.10], [103.80, 1.10], [103.80, 1.25]]] } }
        ]
    };
}

function getMaritimeInfrastructureData() {
    return {
        "type": "FeatureCollection",
        "features": [
            // MUMBAI (Existing)
            { "type": "Feature", "properties": { "type": "tss", "name": "Mumbai TSS", "info": "Mandatory TSS for Mumbai Harbour." }, "geometry": { "type": "Polygon", "coordinates": [[[72.75, 18.90], [72.85, 18.90], [72.85, 18.80], [72.75, 18.80], [72.75, 18.90]]] } },
            
            // ENGLISH CHANNEL / DOVER STRAIT (NEW)
            { "type": "Feature", "properties": { "type": "tss", "name": "Dover Strait TSS (NE Bound)", "info": "Main shipping lane for vessels entering the North Sea." }, "geometry": { "type": "Polygon", "coordinates": [[[1.40, 51.10], [1.60, 51.10], [1.60, 51.00], [1.40, 51.00], [1.40, 51.10]]] } },
            { "type": "Feature", "properties": { "type": "tss", "name": "Dover Strait TSS (SW Bound)", "info": "Main shipping lane for vessels exiting the North Sea." }, "geometry": { "type": "Polygon", "coordinates": [[[1.20, 50.95], [1.40, 50.95], [1.40, 50.85], [1.20, 50.85], [1.20, 50.95]]] } },

            // STRAIT OF GIBRALTAR (NEW)
            { "type": "Feature", "properties": { "type": "tss", "name": "Gibraltar Strait TSS", "info": "Strategic mediterranean entrance traffic lanes." }, "geometry": { "type": "Polygon", "coordinates": [[[-5.50, 35.95], [-5.20, 35.95], [-5.20, 35.85], [-5.50, 35.85], [-5.50, 35.95]]] } },

            // BAB-EL-MANDEB / RED SEA (NEW)
            { "type": "Feature", "properties": { "type": "tss", "name": "Bab-el-Mandeb TSS (Main Channel)", "info": "Critical Red Sea entrance between Yemen and Djibouti." }, "geometry": { "type": "Polygon", "coordinates": [[[43.30, 12.60], [43.60, 12.60], [43.60, 12.40], [43.30, 12.40], [43.30, 12.60]]] } },

            // MALACCA / SINGAPORE
            { "type": "Feature", "properties": { "type": "tss", "name": "Malacca Strait TSS (Singapore)", "info": "Global chokepoint management lanes." }, "geometry": { "type": "Polygon", "coordinates": [[[103.60, 1.20], [103.90, 1.20], [103.90, 1.10], [103.60, 1.10], [103.60, 1.20]]] } },

            // SUEZ CANAL APPROACH
            { "type": "Feature", "properties": { "type": "lane", "name": "Suez Canal Approach", "info": "Managed approach lane for Port Said." }, "geometry": { "type": "LineString", "coordinates": [[32.32, 31.40], [32.32, 31.25]] } },

            // GULF OF OMAN
            { "type": "Feature", "properties": { "type": "tss", "name": "Hormuz/Oman TSS", "info": "Persian Gulf entrance management." }, "geometry": { "type": "Polygon", "coordinates": [[[56.30, 25.80], [56.60, 25.80], [56.60, 25.50], [56.30, 25.50], [56.30, 25.80]]] } },

            // PANAMA Pacific Approach
            { "type": "Feature", "properties": { "type": "lane", "name": "Panama Gulf Lane", "info": "Traffic lane for vessels entering Panama Canal from Pacific." }, "geometry": { "type": "LineString", "coordinates": [[-79.52, 8.85], [-79.52, 8.95]] } }
        ]
    };
}

function initWorldMap() {
    const mapEl = document.getElementById('world-map');
    if (!mapEl) return;
    
    if (worldMap) worldMap.remove();
    
    // 1. Base Layers Definition
    const osmStandard = L.tileLayer('https://mt1.google.com/vt/lyrs=m&hl=en&gl=IN&x={x}&y={y}&z={z}', {
        attribution: '&copy; Google Maps',
        maxZoom: 19
    });

    const darkMatter = L.tileLayer('https://mt1.google.com/vt/lyrs=m&hl=en&gl=IN&x={x}&y={y}&z={z}', {
        attribution: '&copy; Google Maps (Night Nav)',
        maxZoom: 20,
        className: 'dark-map-filter'
    });

    const satelliteView = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: '&copy; Esri World Imagery',
        maxZoom: 18
    });

    // Initialize Map with Dark Mode by default for AI aesthetic
    worldMap = L.map('world-map', {
        center: [19.0760, 72.8777],
        zoom: 5,
        layers: [darkMatter], // Night Nav Default
        zoomControl: false // Move it to right for tactical look
    });

    L.control.zoom({ position: 'topright' }).addTo(worldMap);

    // --- Compass Rose Overlay ---
    const compassDiv = document.createElement('div');
    compassDiv.innerHTML = `
        <svg width="100" height="100" viewBox="0 0 100 100" style="opacity: 0.6; filter: drop-shadow(0 0 5px var(--accent-blue-glow));">
            <circle cx="50" cy="50" r="45" stroke="var(--accent-cyan)" stroke-width="1" fill="none" stroke-dasharray="2,4"/>
            <path d="M50 5 L55 45 L50 42 L45 45 Z" fill="var(--accent-cyan)"/>
            <path d="M50 95 L45 55 L50 58 L55 55 Z" fill="var(--text-dim)"/>
            <path d="M95 50 L55 55 L58 50 L55 45 Z" fill="var(--text-dim)"/>
            <path d="M5 50 L45 45 L42 50 L45 55 Z" fill="var(--text-dim)"/>
            <text x="46" y="15" fill="var(--accent-cyan)" font-size="10" font-family="Orbitron">N</text>
        </svg>
    `;
    compassDiv.style.position = 'absolute';
    compassDiv.style.top = '20px';
    compassDiv.style.left = '20px';
    compassDiv.style.zIndex = '1000';
    compassDiv.style.pointerEvents = 'none';
    const mapDashboard = document.getElementById('world-map');
    if (mapDashboard) mapDashboard.appendChild(compassDiv);

    // 2. Global Search Integration
    L.Control.geocoder({
        defaultMarkGeocode: false,
        placeholder: "Search Port, Strait, or Coords...",
        position: 'topleft'
    }).on('markgeocode', function(e) {
        var bbox = e.geocode.bbox;
        var poly = L.polygon([
            bbox.getSouthEast(),
            bbox.getNorthEast(),
            bbox.getNorthWest(),
            bbox.getSouthWest()
        ]);
        worldMap.fitBounds(poly.getBounds());
    }).addTo(worldMap);
    
    const seamarkLayer = L.tileLayer('https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenSeaMap',
        maxZoom: 18
    }).addTo(worldMap);

    // 1. Global Bathymetry (GEBCO WMS)
    const gebcoLayer = L.tileLayer.wms('https://wms.gebco.net/mapserv', {
        layers: 'GEBCO_LATEST',
        format: 'image/png',
        transparent: true,
        attribution: '© GEBCO Bathymetry',
        opacity: 0.6
    });

    // 2. High-Detail Depth Contours (GeoJSON)
    const contourLayer = L.geoJSON(getDepthContourData(), {
        style: (feature) => {
            const depth = feature.properties.depth;
            let color = '#00d4ff';
            let weight = 2;
            let className = 'depth-contour';

            if (depth <= 5) {
                color = '#ff3860'; // Shallow warning
                weight = 3;
                className += ' depth-contour-5m';
            } else if (depth <= 10) {
                color = '#00d4ff';
                className += ' depth-contour-10m';
            } else {
                color = '#1a3a5a';
                weight = 1;
                className += ' depth-contour-20m';
            }

            return { color, weight, className };
        },
        onEachFeature: (feature, layer) => {
            layer.bindTooltip(`${feature.properties.depth}m`, {
                permanent: true,
                direction: 'center',
                className: 'depth-label'
            });
            layer.bindPopup(`<h5>${feature.properties.name}</h5><p>Measured Depth: <strong>${feature.properties.depth} meters</strong></p>`);
        }
    });

    // 3. Discrete Depth Soundings (Point Soundings)
    const soundingLayer = L.geoJSON(getDepthSoundingPoints(), {
        pointToLayer: (feature, latlng) => {
            return L.marker(latlng, {
                icon: L.divIcon({
                    className: 'depth-sounding-marker',
                    html: `<span>${feature.properties.depth}</span>`,
                    iconSize: [25, 15]
                })
            });
        }
    });

    // 4. Safety Shading (Coastal Shelf)
    const safetyLayer = L.geoJSON(getSafetyShadingData(), {
        style: { className: 'safety-shading-area' },
        onEachFeature: (feature, layer) => {
            layer.bindTooltip(`⚠ ${feature.properties.name} (${feature.properties.risk} Risk)`, {
                sticky: true,
                className: 'safety-tooltip'
            });
        }
    });

    // 5. Marine Hazards (Rock, Wreck, Obstn)
    const hazardLayer = L.geoJSON(getNauticalHazardData(), {
        pointToLayer: (feature, latlng) => {
            const type = feature.properties.type;
            const hazardIcon = L.divIcon({
                className: 'nautical-hazard',
                html: renderHazardSymbol(type),
                iconSize: [24, 24],
                iconAnchor: [12, 12]
            });
            return L.marker(latlng, { 
                icon: hazardIcon,
                zIndexOffset: 500 // Layer above infrastructure but below vessel
            });
        },
        onEachFeature: (feature, layer) => {
            layer.bindPopup(`<h5>${feature.properties.name}</h5><p>Least Depth: <strong>${feature.properties.depth}</strong></p><p>Type: ${feature.properties.type.toUpperCase()}</p>`);
        }
    }).addTo(worldMap); // ADDED: Visible by default

    // 6. Nature of Bottom (S, M, Sh, R)
    const bottomNatureLayer = L.geoJSON(getBottomNatureData(), {
        pointToLayer: (feature, latlng) => {
            const bottomIcon = L.divIcon({
                className: 'bottom-nature-marker',
                html: `<span>${feature.properties.abbr}</span>`,
                iconSize: [30, 30],
                iconAnchor: [15, 15]
            });
            return L.marker(latlng, { 
                icon: bottomIcon,
                zIndexOffset: 700 // High priority
            });
        },
        onEachFeature: (feature, layer) => {
            layer.bindPopup(`<h5>${feature.properties.abbr}: Nature of Bottom</h5><p>Composition: <strong>${feature.properties.desc}</strong></p>`);
        }
    }).addTo(worldMap); // Visible by default

    // 7. Fishing Activity Zones
    const fishingLayer = L.geoJSON(getFishingActivityData(), {
        pointToLayer: (feature, latlng) => {
            const fishingIcon = L.divIcon({
                className: 'fishing-area-marker',
                html: renderFishingIcon(),
                iconSize: [30, 40],
                iconAnchor: [15, 20]
            });
            return L.marker(latlng, { icon: fishingIcon });
        },
        onEachFeature: (feature, layer) => {
            layer.bindPopup(`
                <div class="maritime-popup">
                    <h5 style="color:#e67e22;">Fishing Ground: ${feature.properties.name}</h5>
                    <p><span class="meta-label">Primary Gear:</span> ${feature.properties.gear}</p>
                    <p><span class="meta-label">Navigational Risk:</span> ${feature.properties.risk}</p>
                    <p><em>Exercise extreme caution when transiting.</em></p>
                </div>
            `);
        }
    }).addTo(worldMap); // Visible by default

    // Initialize Infrastructure Layer
    const infraData = getMaritimeInfrastructureData();
    infrastructureLayer = L.geoJSON(infraData, {
        style: (feature) => {
            switch (feature.properties.type) {
                case 'tss': return { color: '#ff3860', weight: 2, className: 'maritime-tss' };
                case 'lane': return { color: '#00d4ff', weight: 4, className: 'maritime-lane' };
                case 'anchorage': return { color: '#ffd700', weight: 2, className: 'maritime-anchorage' };
                default: return { color: '#00ff88', weight: 1 };
            }
        },
        pointToLayer: (feature, latlng) => {
            let color = '#00ff88';
            if (feature.properties.type === 'pilot') color = '#ff74c1';
            return L.circleMarker(latlng, {
                radius: 6,
                fillColor: color,
                color: "#000",
                weight: 1,
                opacity: 1,
                fillOpacity: 0.8
            });
        },
        onEachFeature: (feature, layer) => {
            let content = `<div class="maritime-popup">
                <h5>${feature.properties.name}</h5>
                <p><span class="meta-label">Type:</span> ${feature.properties.type.toUpperCase()}</p>
                <p>${feature.properties.info}</p>`;
            if (feature.properties.characteristic) {
                content += `<div class="characteristic-badge">${feature.properties.characteristic}</div>`;
            }
            content += `</div>`;
            layer.bindPopup(content);
        }
    }).addTo(worldMap);

    // Layer Control
    const graticuleLayer = L.graticule({
        interval: 10,
        style: {
            color: 'rgba(0, 212, 255, 0.2)',
            weight: 1
        }
    }).addTo(worldMap);

    const baseMaps = { 
        "Night Navigation": darkMatter,
        "Satellite View": satelliteView,
        "Standard Map": osmStandard 
    };
    const overlayMaps = {
        "Lat/Lng Grid": graticuleLayer,
        "Infrastructure": infrastructureLayer,
        "Depth Contours": contourLayer,
        "Water Soundings": soundingLayer,
        "Safety Shading": safetyLayer,
        "Marine Hazards": hazardLayer,
        "Nature of Bottom": bottomNatureLayer,
        "Fishing Activity": fishingLayer,
        "Global Bathymetry": gebcoLayer,
        "Maritime Marks": seamarkLayer
    };
    L.control.layers(baseMaps, overlayMaps, { collapsed: false }).addTo(worldMap);
    
    // 3. Scale Bar (Metric & Imperial/Nautical)
    L.control.scale({
        imperial: true,
        metric: true,
        position: 'bottomleft'
    }).addTo(worldMap);
    
    setTimeout(() => {
        if(worldMap) worldMap.invalidateSize();
        // Initial vessel placement based on current inputs
        const startLat = parseFloat(document.getElementById('start-lat').value) || 19.0760;
        const startLng = parseFloat(document.getElementById('start-lng').value) || 72.8777;
        updateVesselOnMap(startLat, startLng);
    }, 500);

    // --- Mouse Coordinate Overlay ---
    const coordDiv = document.createElement('div');
    coordDiv.id = 'map-coords';
    coordDiv.style.position = 'absolute';
    coordDiv.style.bottom = '30px'; // Shifted up slightly to avoid scale bar
    coordDiv.style.left = '10px';
    coordDiv.style.zIndex = '1100';
    coordDiv.style.background = 'rgba(10, 25, 41, 0.9)';
    coordDiv.style.color = '#00f2ff';
    coordDiv.style.padding = '6px 10px';
    coordDiv.style.borderRadius = '4px';
    coordDiv.style.fontSize = '12px';
    coordDiv.style.fontFamily = "'Orbitron', sans-serif";
    coordDiv.style.pointerEvents = 'none';
    coordDiv.style.border = '1px solid var(--accent-cyan)';
    coordDiv.style.boxShadow = '0 0 10px rgba(0, 242, 255, 0.2)';
    coordDiv.textContent = 'LAT: -- | LON: --';
    
    const mapContainer = document.getElementById('world-map');
    if (mapContainer) mapContainer.appendChild(coordDiv);

    worldMap.on('mousemove', (e) => {
        const { lat, lng } = e.latlng;
        coordDiv.textContent = `LAT: ${lat.toFixed(4)}° | LON: ${lng.toFixed(4)}°`;
    });

    console.log('[DeepNav] Leaflet map initialized successfully with coordinate tracker.');
}

function drawWorldMap(data) {
    if (!worldMap) return;
    
    const startLat = parseFloat(document.getElementById('start-lat').value);
    const startLng = parseFloat(document.getElementById('start-lng').value);
    const endLat = parseFloat(document.getElementById('end-lat').value);
    const endLng = parseFloat(document.getElementById('end-lng').value);
    
    // Remove existing layers
    if (worldRouteLine) worldMap.removeLayer(worldRouteLine);
    if (startMarker) worldMap.removeLayer(startMarker);
    if (endMarker) worldMap.removeLayer(endMarker);
    if (vesselMarker) worldMap.removeLayer(vesselMarker);
    
    // Real coordinates from searoute backend logic
    const pathCoordinates = data.actual_route || [[startLat, startLng], [endLat, endLng]];
    
    worldRouteLine = L.polyline(pathCoordinates, {
        color: '#00d4ff', 
        weight: 4, 
        opacity: 0.9,
        className: 'route-line-animated' // Add DASH animation
    }).addTo(worldMap);
    
    // Use the robust update helper
    updateVesselOnMap(startLat, startLng);
    
    const customEndIcon = L.divIcon({
        className: 'custom-map-icon',
        html: '<div style="background-color:#ffd700; width:12px; height:12px; border-radius:50%; box-shadow: 0 0 20px #ffd700; border:2px solid #000;"></div>',
        iconSize: [20, 20]
    });
    
    endMarker = L.marker([endLat, endLng], {icon: customEndIcon}).addTo(worldMap);
    endMarker.bindTooltip(`DEST: ${endLat.toFixed(4)}°, ${endLng.toFixed(4)}°`, {
        permanent: true,
        direction: 'right',
        className: 'nav-coord-label'
    });

    const customStartIcon = L.divIcon({
        className: 'custom-map-icon',
        html: '<div style="background-color:#00ff88; width:10px; height:10px; border-radius:50%; border:1px solid #000;"></div>',
        iconSize: [10, 10]
    });
    startMarker = L.marker([startLat, startLng], {icon: customStartIcon}).addTo(worldMap);
    startMarker.bindTooltip(`ORIGIN: ${startLat.toFixed(4)}°, ${startLng.toFixed(4)}°`, {
        permanent: true,
        direction: 'left',
        className: 'nav-coord-label'
    });
    
    
    // Wait for mapping layer to stabilize then fit bounds
    setTimeout(() => {
        if(worldMap && worldRouteLine) {
            worldMap.invalidateSize();
            try {
                worldMap.fitBounds(worldRouteLine.getBounds(), {padding: [30, 30]});
                const fsBtn = document.getElementById('map-fullscreen-btn');
                if (fsBtn) fsBtn.style.display = 'block';
            } catch(e) {
                console.error("Map fitBounds failed:", e);
            }
        }
    }, 200);
}

// New helper to ensure vessel is always visible
function updateVesselOnMap(lat, lng) {
    if (!worldMap) return;

    if (vesselMarker) {
        worldMap.removeLayer(vesselMarker);
    }

    const vesselIcon = L.divIcon({
        className: 'vessel-marker',
        html: `
            <div class="sonar-ping-active"></div>
            <svg class="ship-icon-svg" width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="position:relative; z-index:10;">
                <path d="M12 2L15 8H9L12 2Z" fill="#00d4ff"/>
                <path d="M4 20L2 14H22L20 20H4Z" fill="#00d4ff"/>
                <rect x="7" y="10" width="10" height="4" fill="#00d4ff" fill-opacity="0.8"/>
            </svg>
        `,
        iconSize: [40, 40],
        iconAnchor: [20, 20]
    });

    vesselMarker = L.marker([lat, lng], {
        icon: vesselIcon,
        zIndexOffset: 1000 // Force to top
    }).addTo(worldMap);

    const latStr = lat.toFixed(4);
    const lngStr = lng.toFixed(4);

    // Get current navigation results from summary grid
    const getVal = (id) => {
        const el = document.getElementById(id);
        return el ? el.textContent : '--';
    };

    const dist = getVal('res-dist');
    const eta = getVal('res-eta');
    const sog = getVal('res-sog');
    const stw = getVal('res-stw');
    const seaDepth = getVal('res-depth');
    const uwDepth = getVal('res-obs-depth-grid');

    vesselMarker.bindPopup(`
        <div class="maritime-popup vessel-popup">
            <h5 style="color:var(--accent-cyan); margin-bottom:10px;">Vessel Status HUD</h5>
            <p><b>Position:</b> ${latStr}°, ${lngStr}°</p>
            <p><b>Remaining:</b> ${dist} / ${eta}</p>
            <p><b>SOG:</b> ${sog}</p>
            <p><b>STW:</b> ${stw}</p>
            <hr style="border:0; border-top:1px solid rgba(255,255,255,0.1); margin:8px 0;"/>
            <p><b>Sea Bottom:</b> ${seaDepth}</p>
            <p style="color:#ff3366;"><b>U/W Obstacle:</b> ${uwDepth}</p>
        </div>
    `, { className: 'vessel-popup-window' });
}

function toggleMapFullscreen() {
    const mapContainer = document.getElementById('world-map');
    if (!mapContainer) return;

    if (!document.fullscreenElement) {
        if (mapContainer.requestFullscreen) {
            mapContainer.requestFullscreen().catch(err => {
                console.error(`Error attempting to enable fullscreen: ${err.message}`);
            });
        }
    } else {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        }
    }
}

document.addEventListener('fullscreenchange', (event) => {
    const exitBtnContainer = document.getElementById('exit-fullscreen-container');
    if (document.fullscreenElement) {
        if (exitBtnContainer) exitBtnContainer.style.display = 'block';
    } else {
        if (exitBtnContainer) exitBtnContainer.style.display = 'none';
    }
    
    if (worldMap) {
        setTimeout(() => {
            worldMap.invalidateSize();
            if (worldRouteLine) {
                try {
                    worldMap.fitBounds(worldRouteLine.getBounds(), {padding: [50, 50]});
                } catch(e) {}
            }
        }, 300);
    }
});
